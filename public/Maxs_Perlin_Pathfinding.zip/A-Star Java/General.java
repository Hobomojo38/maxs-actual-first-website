import java.awt.Color;
import java.util.Random;

//import java.awt.Component; import java.awt.Color; import java.awt.Graphics; import java.awt.Graphics2D; import java.util.Random;

public class General {
    public static void main(String[] args) throws InterruptedException {
        int WIDTH = 700;
        int HEIGHT = 700;
        int PERLIN_MULT = 50;

        Perlin_Noise perlin = new Perlin_Noise(WIDTH, HEIGHT, 15, 15);

        MyFrame window = drawPerlinNoise(perlin);

        Queue<Node> queue = new Queue<Node>();
        Queue<Node> discardQueue = new Queue<Node>();

        Random rand = new Random();

        int startingx = rand.nextInt(WIDTH);
        int startingy = rand.nextInt(HEIGHT);
        window.drawPixel(startingx, startingy, Color.GREEN, 4f);
        System.out.println("Starting position: (" + startingx + ", " + startingy + ")");

        int endingx = rand.nextInt(WIDTH);
        int endingy = rand.nextInt(HEIGHT);
        while (Math.sqrt(Math.pow(endingx - startingx, 2) + Math.pow(endingy - startingy, 2)) < Math.sqrt(Math.pow(WIDTH, 2) + Math.pow(HEIGHT, 2))/2){
            endingx = rand.nextInt(WIDTH);
            endingy = rand.nextInt(HEIGHT);
        }
        window.drawPixel(endingx, endingy, Color.GREEN, 4f);
        System.out.println("Ending position: (" + endingx + ", " + endingy + ")");

        Node startNode = new Node(perlin.noise(startingx, startingy), startingx, startingy);
        startNode.setDistance(endingx, endingy);
        startNode.cost = (double) 0;
        startNode.prev = null;
        

        Node curr = startNode;
        

        while ((curr.x == endingx && curr.y == endingy) == false) {
            int x = curr.x;
            int y = curr.y;
            window.drawPixel(x, y, Color.YELLOW); //draws current node
            window.drawPixel(startingx, startingy, Color.GREEN, 4f); // redraws starting node
            Thread.sleep(1);
            //System.out.println("curr: (" + curr.x + ", " + curr.y + ")");

            if (x != 0) { //left node

                Node leftNode = new Node(perlin.noise(x - 1, y), x - 1, y);

                if (discardQueue.containsNode(leftNode) == false) {
                    leftNode.setDistance(endingx, endingy);
                    leftNode.cost = (leftNode.value - curr.value)*PERLIN_MULT + curr.cost;
                    leftNode.prev = curr;

                    if (queue.containsNode(leftNode)){
                        Node queueNode = queue.getNode(leftNode);
                        if (queueNode.cost > leftNode.cost) {queue.replaceNode(leftNode);}
                    }
                    else{
                        queue.add(leftNode);
                    }
                }
            }

            if (x != WIDTH - 1) { //right node
                Node rightNode = new Node(perlin.noise(x + 1, y), x + 1, y);

                if (discardQueue.containsNode(rightNode) == false) {
                    rightNode.setDistance(endingx, endingy);
                    rightNode.cost = (rightNode.value - curr.value)*PERLIN_MULT + curr.cost;
                    rightNode.prev = curr;

                    if (queue.containsNode(rightNode)){
                        Node queueNode = queue.getNode(rightNode);
                        if (queueNode.cost > rightNode.cost) {queue.replaceNode(rightNode);}
                    }
                    else{
                        queue.add(rightNode);
                    }
                }
            }

            if (y != 0){ //Upper node
                Node upperNode = new Node(perlin.noise(x , y - 1), x, y - 1);

                if (discardQueue.containsNode(upperNode) == false) {
                    upperNode.setDistance(endingx, endingy);
                    upperNode.cost = (upperNode.value - curr.value)*PERLIN_MULT + curr.cost;
                    upperNode.prev = curr;

                    if (queue.containsNode(upperNode)){
                        Node queueNode = queue.getNode(upperNode);
                        if (queueNode.cost > upperNode.cost) {queue.replaceNode(upperNode);}
                    }
                    else{
                        queue.add(upperNode);
                    }
                }
            }
            if (y != HEIGHT - 1) {
                Node lowerNode = new Node(perlin.noise(x, y + 1), x, y + 1);

                if (discardQueue.containsNode(lowerNode) == false) {
                    lowerNode.setDistance(endingx, endingy);
                    lowerNode.cost = (lowerNode.value - curr.value)*PERLIN_MULT + curr.cost;
                    lowerNode.prev = curr;

                    if (queue.containsNode(lowerNode)){
                        Node queueNode = queue.getNode(lowerNode);
                        if (queueNode.cost > lowerNode.cost) {queue.replaceNode(lowerNode);}
                    }
                    else{
                        queue.add(lowerNode);
                    }
                }
            }

            discardQueue.add(curr);
            curr = queue.dequeue();
        }

        //System.out.println("Exiting while loop");

        curr = curr.prev;

        window.drawPixel(endingx, endingy, Color.GREEN, 4f); //redraws ending node


        while (curr.prev != null){
            window.drawPixel(curr.x, curr.y, Color.RED);
            curr = curr.prev;
        }



        
    }

    public static MyFrame drawPerlinNoise(Perlin_Noise perlin) {
        int WIDTH = (int) perlin.xScale;
        int HEIGHT = (int) perlin.yScale;
        
        MyFrame window = new MyFrame(WIDTH, HEIGHT);

        window.setTitle("Perlin Noise Generator");
        
        for (int y = 0; y < HEIGHT; y++){
            for(int x = 0; x < WIDTH; x++){

                double noise = perlin.noise(x, y);

                window.drawPixel(x, y, Color.getHSBColor(1, 0, (float) (1 - (noise / 2 + 0.5))));
            }
        }

        return window;
    }

}
