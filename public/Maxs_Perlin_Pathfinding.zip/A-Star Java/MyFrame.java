import javax.swing.JFrame;

import java.awt.*;


public class MyFrame extends JFrame{

    MyPanel panel;

    MyFrame(int width, int height){
        panel = new MyPanel(width, height);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

        this.add(panel);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public void drawPixel(int x, int y, Color c) {
        panel.drawPixel(x, y, c, this.getGraphics());
    }

    public void drawPixel(int x, int y, Color c, float brushLength) {
        panel.drawPixel(x, y, c, this.getGraphics(), brushLength);
    }

    
    
}
