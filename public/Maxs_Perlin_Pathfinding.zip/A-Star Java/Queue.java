public class Queue<D>{

    private static class Elem<D>{
        D value;
        Elem<D> next;

        private Elem(D val, Elem<D> nxt){
            value = val;
            next = nxt;
        }

        // public int compareTo(D other){
        //     D a = value;
        //     D b = other;

        //     if (a < b) {return -1;}
        //     else if (a == b) {return 0;}
        //     else if (a > b) {return 1;}
        //     else {return 0;}
        // }

        public int compareTo(Node other){
            Node thisNode = (Node) value;
            double a = thisNode.cost + thisNode.distance*0.5;
            double b = other.cost + other.distance*0.5;

            if (a < b) {return -1;}
            else if (a == b) {return 0;}
            else if (a > b) {return 1;}
            else {return 0;}
        }
    }

    private Elem<D> first;
    private Elem<D> last;

    public Queue(){
        first = new Elem<D>(null, null);
        last = new Elem<D>(null, null);

    }

    public int size(){
        int counter = 0;
        Elem<D> current = first.next;
        while (current != null){
            counter++;
            current = current.next;
        }
        return counter;
    }

    public void add(D newEntry){
        if (size() == 0) {first.next = last.next = new Elem<D>(newEntry, null); return ;}

        Elem<D> curr = first;
        boolean done = false;
        while (done == false) {
            // System.out.println("curr.next: " + curr.next);
            // System.out.println("new entry: " + newEntry);
            // System.out.println("Curr: " + curr + ", First: " + first);
            if (curr.next == null) {
                curr.next = new Elem<D>(newEntry, null);
                last.next = curr.next;
                done = true;
            }
            else if (curr.next.compareTo((Node) newEntry) == 1) {
                curr.next = new Elem<D>(newEntry, curr.next);
                done = true;
            }            
            else {curr = curr.next;}
        } 
    }

    public D dequeue(){
        if (size() == 0) {return null;}
        D out = first.next.value;

        first.next = first.next.next;

        return out;
    }

    public void replaceNode(Node newNode){
        boolean done = false;
        Elem<D> curr = first.next;
        while (curr != null && done == false){
            if (((Node) curr.value).isEqual(newNode)) { curr.value = (D) newNode; done = true;}
            else {curr = curr.next;}
        }

    }

    public boolean contains(D item){
        if (item == null) {return false;}
        Elem<D> curr = first.next;
        while (curr != null){
            if (curr.value == item) { return true;}
            else {curr = curr.next;}
        }
        return false;
    }

    public boolean containsNode(Node item){
        if (item == null) {return false;}
        Elem<D> curr = first.next;
        while (curr != null){
            if (((Node) curr.value).isEqual(item)) { return true;}
            else {curr = curr.next;}
        }
        return false;
    }

    public void remove(Node item){
        Elem<D> curr = first.next;
        while (curr.next != null){
            if (item.isEqual((Node) curr.next.value)) {
                curr.next = curr.next.next;
            }
            else {curr = curr.next;}
        }
    }

    public Node getNode(Node item) {
        Elem<D> curr = first.next;
        while (curr != null){
            if (item.isEqual((Node) curr.value)) {
                return (Node) curr.value;
            }
            else {curr = curr.next;}
        }
        return null;

    }

    @Override
    public String toString() {
        String out = "";
        Elem current = first;

        for (int i = 0; i < size(); i++){
            current = current.next;
            out += current.value + "; "; 
        }

        return out;
        
    }

}