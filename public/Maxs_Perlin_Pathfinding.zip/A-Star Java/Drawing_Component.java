import java.awt.Component; import java.awt.Color; import java.awt.Graphics; import java.awt.Graphics2D; import java.util.Random;

public class Drawing_Component extends Component{

    public void paint(Graphics g) { Graphics2D g2d = (Graphics2D) g;
        g.setColor(Color.WHITE);

    }
    
}
