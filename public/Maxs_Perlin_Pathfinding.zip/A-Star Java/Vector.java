public class Vector {
    public double x;
    public double y;

    public Vector(double X, double Y) {
        x = X;
        y = Y;

        normalize();
    }

    public Vector(double X, double Y, boolean normalize) {
        x = X;
        y = Y;

        if (normalize) {
            normalize();
        }
    }

    //Blaitent plaguizm, but it's a cool algo so why not?
    public static double invSqrt(double x) {
        double xhalf = 0.5d * x;
        long i = Double.doubleToLongBits(x);
        i = 0x5fe6ec85e7de30daL - (i >> 1);
        x = Double.longBitsToDouble(i);
        x *= (1.5d - xhalf * x * x);
        return x;
    }

    public void normalize() {
        double invSqrt = invSqrt((Math.pow(x, 2) + Math.pow(y, 2)));

        x = x*invSqrt;
        y = y *invSqrt;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
