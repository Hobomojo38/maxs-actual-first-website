import java.lang.reflect.Array;

public class Node {

    Double value;
    Double distance;
    Double cost;

    int x;
    int y;

    Node prev;
    
    public Node(Double len){
        value = len;
    }

    public Node(Double len, int X, int Y){
        value = len;
        x = X;
        y = Y;
    }

    public boolean isEqual(Node other){
        if (x == other.x && y == other.y){
            return true;
        }
        else {return false;}
    }

    public void setDistance(int otherX, int otherY){
        distance = Math.sqrt(Math.pow(x - otherX, 2) + Math.pow(y - otherY, 2));
    }
}
