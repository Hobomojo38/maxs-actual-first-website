import java.util.Random;

public class Perlin_Noise {
    int width;
    int height;

    double xScale;
    double yScale;
    Random rand = new Random();
    private Vector[][] grid;

    public Perlin_Noise(int Width, int Height, int widthComplexity, int heightComplexity){
        xScale = Width;
        yScale = Height;

        width = widthComplexity;
        height = heightComplexity;

        initalize();

    }

    private double dotProduct(Vector vect1, Vector vect2){
        return vect1.x*vect2.x + vect1.y*vect2.y;
    }

    private double interpolate(double a0, double a1, double x){
        x = 6d * Math.pow(x, 5) - 15d * Math.pow(x, 4) + 10d * Math.pow(x, 3);

        return (a1-a0)*x + a0;
    }

    public double[] bounds(){
        double upper = 0;
        double lower = 0;

        for (int x = 0; x < width*xScale; x++){
            for (int y = 0; y < height*yScale; y++){
                double curr = noise(x,y);
                if (curr > upper) {upper = curr;}
                if (curr < lower) {lower = curr;}
            }}

        double[] bounds = new double[2];
        bounds[0] = upper;
        bounds[1] = lower;

        return bounds;

    }

    public double noise(int x, int y){
        return noise((double) x, (double) y);
    }

    public double noise(double x, double y) {
        x = (x/xScale) * width;
        y = (y/yScale) * height;

        double[] dotProd = new double[4];

        double largeXLeft = Math.floor(x);
        double largeXRight = Math.floor(x) + 1;

        double largeYUp = Math.floor(y);
        double largeYDown = Math.floor(y) + 1;
        //System.out.println("Four corners: " + largeXLeft + ", " + largeXRight + ", " + largeYUp + ", " + largeYDown);

        Vector dVectorTopLeft = new Vector(x - largeXLeft, y - largeYUp, false);
        Vector dVectorTopRight = new Vector(x - largeXRight, y - largeYUp, false);
        Vector dVectorBottomLeft = new Vector(x - largeXLeft, y - largeYDown, false);
        Vector dVectorBottomRight = new Vector(x - largeXRight, y - largeYDown, false);
        
        //System.out.println("" + dVectorTopLeft + dVectorTopRight + dVectorBottomLeft + dVectorBottomRight);

        dotProd[0] = dotProduct(grid[(int) largeXLeft][(int) largeYUp], dVectorTopLeft);
        dotProd[1] = dotProduct(grid[(int) largeXRight][(int) largeYUp], dVectorTopRight);
        dotProd[2] = dotProduct(grid[(int) largeXLeft][(int) largeYDown], dVectorBottomLeft);
        dotProd[3] = dotProduct(grid[(int) largeXRight][(int) largeYDown], dVectorBottomRight);
        //System.out.println("dotProds: " + dotProd[0] + " " + dotProd[1] + " " + dotProd[2] + " " + dotProd[3]);

        double interp1 = interpolate(dotProd[0], dotProd[1], x - largeXLeft);
        double interp2 = interpolate(dotProd[2], dotProd[3], x - largeXLeft);

        double interp3 = interpolate(interp1, interp2, y - largeYUp);

        return interp3;
    }

    public void initalize(){

        grid = new Vector[width + 1][height + 1];

        for (int x = 0; x < width + 1; x++){
            for (int y = 0; y < height + 1; y++){
                Vector vect = new Vector(rand.nextDouble()*2 - 1, rand.nextDouble() * 2 - 1);

                //System.out.println("(x, y): " + "(" + x + ", " + y + ") " + vect);

                grid[x][y] = vect;
            }
        }
    }
}
