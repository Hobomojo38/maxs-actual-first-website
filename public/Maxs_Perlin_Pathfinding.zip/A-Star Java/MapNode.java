public class MapNode {

    float value;

    int[] coordinates;

    public MapNode(float Value, int x, int y){
        value = Value;

        coordinates = new int[2];
        coordinates[0] = x;
        coordinates[1] = y;
    }

    public float distanceTo(int[] otherCoordinates){
        return (float) Math.sqrt(Math.pow(otherCoordinates[0] - coordinates[0], 2) + Math.pow(otherCoordinates[1] - coordinates[1], 2));
    }
    
}
