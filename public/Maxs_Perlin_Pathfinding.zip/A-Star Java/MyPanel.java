import javax.swing.JPanel;
import javax.swing.text.AttributeSet.ColorAttribute;

import org.w3c.dom.css.RGBColor;

import java.awt.*;

public class MyPanel extends JPanel{
    int WIDTH;
    int HEIGHT;
    
    MyPanel(int width, int height){
        WIDTH = width;
        HEIGHT = height;
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));

    }
    
    public void paint(Graphics g) {

    }

    public void drawPixel(int x, int y, Color c, Graphics g){

        Graphics2D g2d = (Graphics2D) g;

        g2d.setColor(c);
        BasicStroke stroke = new BasicStroke(2f);
        g2d.setStroke(stroke);

        g2d.drawLine(x, y, x, y);
    }

    public void drawPixel(int x, int y, Color c, Graphics g, float brushLength){

        Graphics2D g2d = (Graphics2D) g;

        g2d.setColor(c);
        BasicStroke stroke = new BasicStroke(brushLength);
        g2d.setStroke(stroke);

        g2d.drawLine(x, y, x, y);
    }


    
}
